Details of setup and prereqisites are in the file Read Me Linux NRI.docx

basic setup
copy the contents of this folder to an empty file on your Client Automation Domain Manager

open a command prompt on the domain manager
run dmscript <directory files are in>\install.txt
follow the prompts 